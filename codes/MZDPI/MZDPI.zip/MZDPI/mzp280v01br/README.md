
mzp280v01br(ZERO B)

in config.txt add
[all]
include mzp280v01br.txt
