
mzp280v02br(ZERO B+)

in config.txt add
[all]
include mzp280v02br.txt
