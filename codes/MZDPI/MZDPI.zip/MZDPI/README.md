    cd ~/

    git clone https://github.com/tianyoujian/MZDPI.git

    cd MZDPI/vga

    sudo chmod +x mzdpi-vga-autoinstall-online

    sudo ./mzdpi-vga-autoinstall-online

    sudo reboot
